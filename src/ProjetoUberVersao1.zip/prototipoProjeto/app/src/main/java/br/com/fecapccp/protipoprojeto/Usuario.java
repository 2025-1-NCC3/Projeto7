package br.com.fecapccp.protipoprojeto;

public class Usuario {
    private String email;
    private String senha;

    public Usuario(String email, String senha) {
        this.email = email;
        this.senha = senha;
    }

    // Getters e Setters (opcional, dependendo do uso)
}

package br.com.fecapccp.ubersminions;

public class ApiResponse {
    private String message;

    public String getMessage() {
        return message;
    }
}


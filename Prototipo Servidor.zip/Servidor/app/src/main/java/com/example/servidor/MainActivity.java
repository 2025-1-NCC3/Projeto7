package com.example.servidor;

import android.os.Bundle; // para passar informações entre diferentes atividades
import android.os.AsyncTask; // para realizar operações assíncronas - Ele foi descontinuado no Android API 30
import android.util.Log; // para registrar mensagens de log, para depuração de código
import android.widget.TextView; // para exibir textos na interface gráfica

import androidx.appcompat.app.AppCompatActivity; // classe de compartibilidade com versões antigas do Android
import java.io.BufferedReader; // para ler dados de resposta HTTP
import java.io.InputStreamReader; // para ler bytes de resposta HTTP
import java.lang.ref.WeakReference; // para evitar vazamentos de memória, mantendo uma referência fraca com a MainActivity
import java.net.HttpURLConnection; // para abrir e configurar a conexão HTTP
import java.net.URL; // para abrir e configurar a conexão HTTP
import org.json.JSONArray; // para lidar com dados JSON retornados pelo servidor
import org.json.JSONObject; // para lidar com dados JSON retornados pelo servidor

public class MainActivity extends AppCompatActivity {

    // URL base do servidor onde será enviada a requisição GET
    private static final String BASE_URL = "https://4f6gyg-3000.csb.app/tudo"; // IP do servidor

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // chama o AsyncTask para fazer a requisição GET ao servidor
        new GetDataTask(this).execute(BASE_URL);
    }

    // AsyncTask para realizar a requisição GET e processar de forma assíncrona
    private static class GetDataTask extends AsyncTask<String, Void, String> {

        private WeakReference<MainActivity> activityReference;

        // construtor para passar o contexto da MainActivity e garantir que ela será atualizada
        GetDataTask(MainActivity context) {
            activityReference = new WeakReference<>(context);
        }

        @Override
        // metodo que roda em segundo plano e processa a requisição
        protected String doInBackground(String... urls) { // a URL passada através do BaseURL para o metodo execute() vem até aqui como uma String chamada urls
            String result = null;
            HttpURLConnection urlConnection = null; // cria uma conexão que irá tentar se conectar a URL fornecida
            BufferedReader reader = null;

            try {
                URL url = new URL(urls[0]); // a url é a urls[0](a primeira e única que passamos)
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET"); // define o metodo da requisição como GET
                urlConnection.setConnectTimeout(15000); // timeout de conexão
                urlConnection.setReadTimeout(15000);    // timeout de leitura

                int statusCode = urlConnection.getResponseCode(); // verificar o código de status HTTP
                if (statusCode == HttpURLConnection.HTTP_OK) {
                    InputStreamReader inputStreamReader = new InputStreamReader(urlConnection.getInputStream());
                    reader = new BufferedReader(inputStreamReader);

                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        stringBuilder.append(line);
                    }
                    result = stringBuilder.toString();
                } else {
                    Log.e("GetDataTask", "Erro na requisição: " + statusCode);
                }
            } catch (Exception e) {
                Log.e("GetDataTask", "Erro na requisição GET", e);
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (Exception e) {
                        Log.e("GetDataTask", "Erro ao fechar o BufferedReader", e);
                    }
                }
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }
            return result;
        }


        @Override
        // este metodo é chamado após a requisição ser concluída, ele processa os dados recebidos no formato JSON
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            MainActivity activity = activityReference.get();  // Obtém a referência da MainActivity
            if (activity != null && result != null) {
                try {
                    // parse a resposta JSON (extração dos daods para serem utilizados corretamente)
                    JSONArray jsonArray = new JSONArray(result);
                    StringBuilder displayData = new StringBuilder();

                    // percorre todos os itens do JSON
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        Integer id = jsonObject.getInt("id");
                        String nome = jsonObject.getString("nome");
                        String senha = jsonObject.getString("senha");

                        // adiciona os dados para exibição
                        displayData.append("ID: ").append(id).append("\n");
                        displayData.append("Nome: ").append(nome).append("\n");
                        displayData.append("Senha: ").append(senha).append("\n\n");
                    }

                    // exibe os dados na TextView
                    TextView textView = activity.findViewById(R.id.txt_message); // Acessa a TextView corretamente
                    textView.setText(displayData.toString());

                } catch (Exception e) {
                    Log.e("MainActivity", "Erro ao processar a resposta JSON", e);
                }
            } else {
                Log.e("MainActivity", "Erro ao obter dados");
            }
        }
    }
}
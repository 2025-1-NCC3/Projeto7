package com.example.servidor;

import android.os.Bundle;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private static final String BASE_URL = "https://4f6gyg-3000.csb.app/tudo"; // IP do servidor

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Chama o AsyncTask para fazer a requisição GET ao servidor
        new GetDataTask(this).execute(BASE_URL);
    }

    // AsyncTask para realizar a requisição GET
    private static class GetDataTask extends AsyncTask<String, Void, String> {

        private WeakReference<MainActivity> activityReference;

        // Construtor para passar o contexto da MainActivity
        GetDataTask(MainActivity context) {
            activityReference = new WeakReference<>(context);
        }

        @Override
        protected String doInBackground(String... urls) {
            String result = null;
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;

            try {
                URL url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setConnectTimeout(15000); // Timeout de conexão
                urlConnection.setReadTimeout(15000);    // Timeout de leitura

                int statusCode = urlConnection.getResponseCode(); // Verificar o código de status HTTP
                if (statusCode == HttpURLConnection.HTTP_OK) {
                    InputStreamReader inputStreamReader = new InputStreamReader(urlConnection.getInputStream());
                    reader = new BufferedReader(inputStreamReader);

                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        stringBuilder.append(line);
                    }
                    result = stringBuilder.toString();
                } else {
                    Log.e("GetDataTask", "Erro na requisição: " + statusCode);
                }
            } catch (Exception e) {
                Log.e("GetDataTask", "Erro na requisição GET", e);
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (Exception e) {
                        Log.e("GetDataTask", "Erro ao fechar o BufferedReader", e);
                    }
                }
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }
            return result;
        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            MainActivity activity = activityReference.get();  // Obtém a referência da MainActivity
            if (activity != null && result != null) {
                try {
                    // Parse a resposta JSON
                    JSONArray jsonArray = new JSONArray(result);
                    StringBuilder displayData = new StringBuilder();

                    // Percorre todos os itens do JSON
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        Integer id = jsonObject.getInt("id");
                        String nome = jsonObject.getString("nome");
                        String senha = jsonObject.getString("senha");

                        // Adiciona os dados para exibição
                        displayData.append("ID: ").append(id).append("\n");
                        displayData.append("Nome: ").append(nome).append("\n");
                        displayData.append("Senha: ").append(senha).append("\n\n");
                    }

                    // Exibe os dados na TextView
                    TextView textView = activity.findViewById(R.id.txt_message); // Acessa a TextView corretamente
                    textView.setText(displayData.toString());

                } catch (Exception e) {
                    Log.e("MainActivity", "Erro ao processar a resposta JSON", e);
                }
            } else {
                Log.e("MainActivity", "Erro ao obter dados");
            }
        }
    }
}